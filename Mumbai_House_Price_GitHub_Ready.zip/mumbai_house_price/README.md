# Mumbai House Price Prediction (Regression + Deep Learning + Streamlit)

## Quick start
```bash
python -m venv venv
venv\Scripts\activate          # Windows  (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
python generate_data.py        # creates data/mumbai_house_data.csv (synthetic sample data)
python train_model.py          # trains 3 models, saves models/ and figures/
streamlit run app.py           # opens the web app in your browser
```
(If you skip `train_model.py`, the app trains automatically on first launch.)

## Using REAL data
Replace `data/mumbai_house_data.csv` with a real dataset that has these columns:
`locality, region, bhk, area_sqft, floor, total_floors, age_years, status, furnishing, parking,
amenities_score, dist_station_km, sea_facing, price_lakh`
(rename/derive columns from a Kaggle "Mumbai house prices" file; convert price to lakh; missing columns can be
removed from CAT_COLS / NUM_COLS at the top of train_model.py). Then re-run `train_model.py`
and update the numbers in your paper.

## Deploy on Streamlit Community Cloud
1. Push this folder to a GitHub repository (include data/, models/, figures/, app.py, train_model.py, generate_data.py, requirements.txt).
2. Go to share.streamlit.io -> New app -> choose the repo, branch and `app.py` -> Deploy.
3. Paste the live URL and GitHub link into Section 9 of the paper.

## Files
| File | Purpose |
|---|---|
| generate_data.py | Builds the synthetic dataset (6,000 flats, 21 localities) |
| train_model.py | Cleaning, Linear Regression, Gradient Boosting, MLP, metrics, CV, charts |
| app.py | Streamlit app |
